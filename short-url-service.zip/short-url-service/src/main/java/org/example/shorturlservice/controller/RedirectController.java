package org.example.shorturlservice.controller;

import org.example.shorturlservice.service.ShortUrlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.servlet.http.HttpServletResponse; // 注意：是 jakarta
import java.io.IOException;

@Controller
public class RedirectController {

    @Autowired
    private ShortUrlService shortUrlService;

    /**
     * 核心重定向功能：
     * 用户访问 http://localhost:8080/短码 时，
     * 此接口会根据短码找到原始长链接，并执行 302 重定向跳转。
     */
    @GetMapping("/{shortCode}")
    public void redirect(@PathVariable String shortCode, HttpServletResponse response) throws IOException {
        try {
            // 从 Service 层获取原始长链接
            String originalUrl = shortUrlService.getOriginalUrl(shortCode);

            // 执行 302 重定向
            response.sendRedirect(originalUrl);
        } catch (RuntimeException e) {
            // 如果短链不存在或被禁用，返回 404 错误页面和提示信息
            response.sendError(HttpServletResponse.SC_NOT_FOUND, e.getMessage());
        }
    }
}