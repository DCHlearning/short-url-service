package org.example.shorturlservice.entity;

import lombok.Data;
import jakarta.persistence.*; // 注意这里：是 jakarta，不是 javax
import java.time.LocalDateTime;

@Entity
@Table(name = "short_urls")
@Data
public class ShortUrl {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 1000)
    private String originalUrl;

    @Column(unique = true, nullable = false)
    private String shortCode;

    @Column(nullable = false)
    private String name;

    private LocalDateTime createdAt = LocalDateTime.now();
    private Boolean enabled = true;
    private Long clickCount = 0L;
    private String appId;
}