package org.example.shorturlservice.controller;

import org.example.shorturlservice.entity.ShortUrl;
import org.example.shorturlservice.repository.ShortUrlRepository;
import org.example.shorturlservice.service.ShortUrlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/shortlinks")
public class ShortUrlController {

    @Autowired
    private ShortUrlService shortUrlService;

    @Autowired
    private ShortUrlRepository shortUrlRepository;

    // 1. 获取短链接列表（支持按名称搜索）
    @GetMapping
    public List<ShortUrl> list(@RequestParam(required = false) String name) {
        if (name != null && !name.isEmpty()) {
            return shortUrlRepository.findByNameContaining(name);
        }
        return shortUrlRepository.findAll();
    }

    // 2. 生成短链接
    @PostMapping("/generate")
    public Map<String, String> generate(@RequestBody Map<String, String> request) {
        String url = request.get("url");
        String name = request.get("name");
        String shortCode = shortUrlService.generateShortCode(url, name);

        // 返回完整的短链接地址（假设后端运行在 8080 端口）
        return Collections.singletonMap("shortUrl", "http://localhost:8080/" + shortCode);
    }

    // 3. 启用/禁用短链接
    @PatchMapping("/{id}/status")
    public void toggleStatus(@PathVariable Long id, @RequestBody Map<String, Boolean> body) {
        ShortUrl shortUrl = shortUrlRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("找不到该短链接"));
        shortUrl.setEnabled(body.get("enabled"));
        shortUrlRepository.save(shortUrl);
    }

    // 4. 删除短链接
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        shortUrlRepository.deleteById(id);
    }
}