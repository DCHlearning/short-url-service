package org.example.shorturlservice.service;

import org.example.shorturlservice.entity.ShortUrl;
import org.example.shorturlservice.repository.ShortUrlRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ShortUrlService {

    @Autowired
    private ShortUrlRepository shortUrlRepository;

    private static final String BASE62 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final int CODE_LENGTH = 8;

    // 生成短链接
    public String generateShortCode(String originalUrl, String name) {
        // 1. 生成唯一短码
        String shortCode;
        do {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < CODE_LENGTH; i++) {
                sb.append(BASE62.charAt((int) (Math.random() * 62)));
            }
            shortCode = sb.toString();
        } while (shortUrlRepository.findByShortCode(shortCode).isPresent());

        // 2. 保存到数据库
        ShortUrl shortUrl = new ShortUrl();
        shortUrl.setOriginalUrl(originalUrl);
        shortUrl.setShortCode(shortCode);
        shortUrl.setName(name);
        shortUrlRepository.save(shortUrl);

        return shortCode;
    }

    // 获取原始链接并记录点击
    public String getOriginalUrl(String shortCode) {
        Optional<ShortUrl> shortUrlOpt = shortUrlRepository.findByShortCode(shortCode);
        if (shortUrlOpt.isPresent()) {
            ShortUrl shortUrl = shortUrlOpt.get();
            if (shortUrl.getEnabled()) {
                shortUrl.setClickCount(shortUrl.getClickCount() + 1);
                shortUrlRepository.save(shortUrl);
                return shortUrl.getOriginalUrl();
            }
            throw new RuntimeException("该短链已被禁用");
        }
        throw new RuntimeException("短链不存在");
    }
}